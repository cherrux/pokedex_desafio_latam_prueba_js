# pokedex_desafio_latam_prueba_js
 pokedex desafio latam prueba js
